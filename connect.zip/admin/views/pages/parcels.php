<div class="container-scroller">
      <!-- partial:../../partials/_navbar.html -->
    
      <!-- partial -->
      <div class="container-fluid page-body-wrapper">
        <!-- partial:../../partials/_sidebar.html -->
     
        <!-- partial sidebar -->
        <div class="main-panel col-12">
          <div class="content-wrapper">
            <div class="page-header">
              <h3 class="page-title"> All Parcels </h3>
            </div>
            <div class="row">
              <div class="col-12 grid-margin stretch-card">
                <table class="table table-striped table-bordered table-hover">
                  <thead>
                    <tr>
                      <th> Tracking ID </th>
                      <th> Sender Name </th>
                      <th> Receiver Name </th>
                      <th> Origin </th>
                      <th> Destination </th>
                      <th> Status </th>
                      <th> Date </th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td> 1 </td>
                      <td> John Doe </td>
                      <td> Jane Doe </td>
                      <td> New York </td>
                      <td> Los Angeles </td>
                      <td><label class="badge badge-danger">Pending</label></td>
                      <td> 2023-10-01 </td>
                    </tr>
                    <tr>
                      <td> 2 </td>
                      <td> Mark Smith </td>
                      <td> Lucy Brown </td>
                      <td> Chicago </td>
                      <td> Houston </td>
                      <td><label class="badge badge-success">Delivered</label></td>
                      <td> 2023-10-02 </td>
                    </tr>
                    <tr>
                      <td> 3 </td>
                      <td> Michael Johnson </td>
                      <td> Emily Davis </td>
                      <td> Miami </td>
                      <td> Atlanta </td>
                      <td><label class="badge badge-warning">In Transit</label></td>
                      <td> 2023-10-03 </td>
                    </tr>

                  </tbody >

                </table>
                </div>
          </div>
          <!-- content-wrapper ends -->
          <!-- partial:../../partials/_footer.html -->
            <div>
              <div class="">
                   <a href=""> <button class="btn btn-primary btn-sm">Add Parcel</button></a>
                  </div>
            </div>
          <!-- partial footer -->
        </div>
        <!-- main-panel ends -->
      </div>
      <!-- page-body-wrapper ends -->
    </div>

  